require("dotenv").config();

const crypto = require("node:crypto");
const express = require("express");
const path = require("node:path");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const { rateLimit } = require("express-rate-limit");
const { z } = require("zod");
const db = require("./db");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === "production";
const COOKIE_SECURE = process.env.COOKIE_SECURE === "true";
const SESSION_SECRET = process.env.SESSION_SECRET || "";

if (IS_PROD && SESSION_SECRET.length < 32) {
  throw new Error("SESSION_SECRET must be at least 32 characters in production.");
}
if (IS_PROD && !COOKIE_SECURE) {
  throw new Error("Set COOKIE_SECURE=true in production (HTTPS required).");
}

app.disable("x-powered-by");
app.set("trust proxy", IS_PROD ? 1 : false);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: IS_PROD ? [] : null
    }
  }
}));
app.use(express.json({ limit: "10kb" }));
app.use(cookieParser());

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Слишком много попыток. Попробуй позже." }
});
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 120,
  standardHeaders: "draft-7",
  legacyHeaders: false
});

const COOKIE_NAME = "dake_session";
const SESSION_TTL_SECONDS = 60 * 60 * 24 * 7;

const registerSchema = z.object({
  username: z.string().trim().min(3).max(24).regex(/^[\p{L}\p{N}_-]+$/u, "Имя может содержать буквы, цифры, _ и -"),
  email: z.string().trim().email().max(254),
  password: z.string().min(10).max(72)
});
const loginSchema = z.object({
  email: z.string().trim().email().max(254),
  password: z.string().min(1).max(72)
});

function safeUser(row) {
  return { id: row.id, username: row.username, email: row.email, role: row.role, createdAt: row.created_at };
}
function cookieOptions() {
  return {
    httpOnly: true,
    secure: COOKIE_SECURE,
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_TTL_SECONDS * 1000
  };
}
function createSession(userId) {
  // Random opaque session token; only its SHA-256 hash is stored in SQLite.
  const token = crypto.randomBytes(32).toString("base64url");
  const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
  const expiresAt = Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS;
  db.prepare("INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, ?)").run(tokenHash, userId, expiresAt);
  return token;
}
function tokenHash(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}
function requireAuth(req, res, next) {
  const token = req.cookies[COOKIE_NAME];
  if (!token || typeof token !== "string") return res.status(401).json({ error: "Сначала войди в аккаунт." });
  const session = db.prepare(`
    SELECT s.id AS session_id, s.expires_at, u.id, u.username, u.email, u.role, u.created_at
    FROM sessions s JOIN users u ON u.id = s.user_id
    WHERE s.id = ? AND s.expires_at > ?
  `).get(tokenHash(token), Math.floor(Date.now() / 1000));
  if (!session) {
    res.clearCookie(COOKIE_NAME, { httpOnly: true, secure: COOKIE_SECURE, sameSite: "lax", path: "/" });
    return res.status(401).json({ error: "Сессия истекла. Войди снова." });
  }
  req.user = safeUser(session);
  req.sessionId = session.session_id;
  next();
}
function requireAdmin(req, res, next) {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Недостаточно прав." });
  next();
}

// For same-origin deployment, cookie SameSite=Lax and Origin checking reduce CSRF risk.
// If frontend is hosted separately, configure a strict allowlist and use HTTPS.
app.use("/api", apiLimiter, (req, res, next) => {
  const origin = req.get("origin");
  const allowed = process.env.FRONTEND_ORIGIN;
  if (origin && allowed && origin !== allowed) {
    return res.status(403).json({ error: "Запрос с неизвестного источника заблокирован." });
  }
  next();
});

app.get("/api/health", (req, res) => res.json({ ok: true, service: "Dake Company API" }));

app.post("/api/auth/register", authLimiter, (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({
      error: "Проверь введённые данные.",
      details: parsed.error.issues.map(i => ({ field: i.path.join("."), message: i.message }))
    });
  }
  const username = parsed.data.username;
  const email = parsed.data.email.toLowerCase();
  const passwordHash = bcrypt.hashSync(parsed.data.password, 12);
  try {
    const result = db.prepare("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)")
      .run(username, email, passwordHash);
    const user = db.prepare("SELECT id, username, email, role, created_at FROM users WHERE id = ?").get(result.lastInsertRowid);
    const token = createSession(user.id);
    res.cookie(COOKIE_NAME, token, cookieOptions());
    return res.status(201).json({ user: safeUser(user) });
  } catch (err) {
    if (String(err.code || "").includes("SQLITE_CONSTRAINT_UNIQUE")) {
      return res.status(409).json({ error: "Этот e-mail уже зарегистрирован." });
    }
    console.error("Registration error:", err.message);
    return res.status(500).json({ error: "Не удалось создать аккаунт." });
  }
});

app.post("/api/auth/login", authLimiter, (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Укажи корректный e-mail и пароль." });
  const email = parsed.data.email.toLowerCase();
  const row = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  // Same message for missing email and wrong password, avoiding account enumeration.
  if (!row || !bcrypt.compareSync(parsed.data.password, row.password_hash)) {
    return res.status(401).json({ error: "Неверный e-mail или пароль." });
  }
  const token = createSession(row.id);
  res.cookie(COOKIE_NAME, token, cookieOptions());
  return res.json({ user: safeUser(row) });
});

app.get("/api/auth/me", requireAuth, (req, res) => res.json({ user: req.user }));

app.post("/api/auth/logout", requireAuth, (req, res) => {
  db.prepare("DELETE FROM sessions WHERE id = ?").run(req.sessionId);
  res.clearCookie(COOKIE_NAME, { httpOnly: true, secure: COOKIE_SECURE, sameSite: "lax", path: "/" });
  res.status(204).end();
});

// Example protected endpoint.
app.get("/api/account", requireAuth, (req, res) => {
  const orderCount = 0; // Connect this to the orders table when order processing is added.
  res.json({ user: req.user, orderCount });
});

// Example admin-only endpoint. Promote a trusted account manually in the database;
// never expose role selection during public registration.
app.get("/api/admin/overview", requireAuth, requireAdmin, (req, res) => {
  const users = db.prepare("SELECT COUNT(*) AS count FROM users").get().count;
  res.json({ users, note: "Добавь таблицы товаров и заказов на следующем этапе." });
});

// Serve static frontend from public/ when present.
const publicDir = path.join(__dirname, "..", "public");
app.use(express.static(publicDir));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(publicDir, "index.html"), err => {
    if (err) res.status(404).send("Frontend not found. Put index.html in the public/ folder.");
  });
});

app.use((err, req, res, next) => {
  console.error("Unhandled error:", err.message);
  res.status(500).json({ error: "Внутренняя ошибка сервера." });
});

const cleanup = () => {
  db.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(Math.floor(Date.now() / 1000));
};
cleanup();
setInterval(cleanup, 60 * 60 * 1000).unref();

app.listen(PORT, () => {
  console.log(`Dake Company API is running at http://localhost:${PORT}`);
});
