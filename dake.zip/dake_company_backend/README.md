# Dake Company — backend с безопасной базовой авторизацией

## Что включено
- Node.js + Express API.
- SQLite база данных для пользователей и сессий.
- Пароли хешируются bcrypt (12 раундов), пароли не сохраняются открытым текстом.
- Случайные непрозрачные токены сессии; в БД хранится только SHA-256-хеш токена.
- HttpOnly cookie, SameSite=Lax, возможность включить Secure для HTTPS.
- Валидация входных данных, лимит размера JSON, rate limiting для авторизации и API.
- Helmet security headers.
- Единые ошибки входа для неизвестного e-mail и неправильного пароля.
- Пример закрытого пользовательского endpoint и admin-only endpoint.
- Роль пользователя нельзя выбрать при публичной регистрации.

## Запуск локально
Нужен Node.js 20 или новее.

1. Распакуй проект.
2. Открой терминал в папке проекта.
3. Установи зависимости:
   `npm install`
4. Скопируй `.env.example` в `.env`.
5. Для локального теста можно оставить `COOKIE_SECURE=false`; поменяй SESSION_SECRET на случайную строку длиной не менее 32 символов.
6. Запусти:
   `npm start`
7. Открой `http://localhost:3000/api/health`.

SQLite файл создаётся автоматически в `data/dake-company.db`.

## API
### Регистрация
`POST /api/auth/register`
```json
{"username":"Player_01","email":"player@example.com","password":"a-long-demo-password"}
```

### Вход
`POST /api/auth/login`
```json
{"email":"player@example.com","password":"a-long-demo-password"}
```

### Текущий пользователь
`GET /api/auth/me`

### Выход
`POST /api/auth/logout`

### Защищённый профиль
`GET /api/account`

### Пример для администратора
`GET /api/admin/overview`

Для браузерных запросов cookie обрабатывается автоматически при same-origin размещении. Пример:
```js
const response = await fetch('/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  credentials: 'same-origin',
  body: JSON.stringify({ email, password })
});
const data = await response.json();
```

## Настройка production
- Размещай backend только за HTTPS.
- В `.env` установи `NODE_ENV=production`, `COOKIE_SECURE=true`, `SESSION_SECRET` — длинный случайный секрет.
- Укажи точный `FRONTEND_ORIGIN`. Самый простой вариант — обслуживать frontend и API с одного origin.
- Не коммить `.env` и базу данных.
- Настрой регулярные резервные копии базы данных и мониторинг.
- Для нескольких серверных экземпляров используй PostgreSQL и общий session store вместо локального SQLite.
- Не создавай админов через публичную регистрацию. Назначай роль только вручную/через защищённую административную процедуру.
- Перед реальным запуском добавь подтверждение e-mail, восстановление пароля, CSRF-защиту при cross-site сценариях, журнал аудита и тесты.

## Важно
Это безопасная стартовая основа, а не полностью готовая коммерческая платформа. Здесь пока нет реальных платежей, таблиц товаров/заказов и автоматической выдачи цифровых товаров. Frontend текущего демо-магазина нужно подключить к этим API — не хранить пароли и авторизацию только в localStorage.
